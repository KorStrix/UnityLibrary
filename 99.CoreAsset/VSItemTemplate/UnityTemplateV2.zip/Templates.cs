﻿#region Header
/* ============================================ 
 *			    Strix Unity Library
 *		https://github.com/strix13/UnityLibrary
 *	============================================
 *	작성자 : Strix
 *	작성일 : $time$
 *	기능 : 
   ============================================ */
#endregion Header

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class $itemname$
{
    /* const & readonly declaration             */

	/* enum & struct declaration                */

    /* public - Field declaration            */


    /* protected & private - Field declaration         */


    // ========================================================================== //

	/* public - [Do] Function
     * 외부 객체가 호출(For External class call)*/


	// ========================================================================== //

    /* protected - Override & Unity API         */
    

    /* protected - [abstract & virtual]         */


    // ========================================================================== //

    #region Private

    #endregion Private

    // ========================================================================== //

    #region Test

    #endregion Test
}
